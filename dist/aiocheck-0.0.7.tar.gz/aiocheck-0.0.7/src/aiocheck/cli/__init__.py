"""
    Entrypoint for running the CLI script

    Example:
    ```
    aiocheck.cli.main(['localhost'])
    ```
"""

from aiocheck.cli.main import main
