"""
    Entrypoint for running the CLI script

    Example:
    ```
    aiocheck.cli.main()
    ```
"""

from aiocheck.cli.main import main
